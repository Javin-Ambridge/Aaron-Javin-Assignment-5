#ifndef RANDOMGENERATOR_H
#define RANDOMGENERATOR_H

class RandomGenerator {
	
	public:
		RandomGenerator();
		int getDiceRoll();
		int getSLCRoll();
		int getNeedlesRoll();
		bool wonRollupCup();
};

#endif
