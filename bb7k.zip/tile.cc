#include "tile.h"
using namespace std;

Tile::~Tile(){

}
